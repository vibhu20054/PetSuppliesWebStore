import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        LoginDAO loginDAO = new LoginDAO();
        PetSupplyDAO dao = new PetSupplyDAO();

        // ---------- LOGIN ----------
        System.out.println("===== PET SUPPLIES LOGIN =====");
        System.out.print("Enter Username: ");
        String username = sc.nextLine();

        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        if (!loginDAO.login(username, password)) {
            System.out.println("❌ Invalid Login! Exiting...");
            System.exit(0);
        }

        System.out.println("✅ Login Successful!");

        // ---------- MENU ----------
        while (true) {
            System.out.println("\n----- PET SUPPLIES SYSTEM -----");
            System.out.println("1. Add Item");
            System.out.println("2. View Items");
            System.out.println("3. Update Price");
            System.out.println("4. Delete Item");
            System.out.println("5. Search Item");
            System.out.println("6. Exit");
            System.out.print("Enter choice: ");

            int ch = sc.nextInt();
            sc.nextLine(); // IMPORTANT: clear buffer

            switch (ch) {
                case 1:
                    System.out.print("Name: ");
                    String name = sc.nextLine();

                    System.out.print("Category: ");
                    String cat = sc.nextLine();

                    System.out.print("Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine();

                    dao.addItem(new Item(name, cat, price));
                    break;

                case 2:
                    dao.viewItems();
                    break;

                case 3:
                    System.out.print("Enter Item ID: ");
                    int id1 = sc.nextInt();

                    System.out.print("New Price: ");
                    double newPrice = sc.nextDouble();
                    sc.nextLine();

                    dao.updatePrice(id1, newPrice);
                    break;

                case 4:
                    System.out.print("Enter Item ID: ");
                    int id2 = sc.nextInt();
                    sc.nextLine();

                    dao.deleteItem(id2);
                    break;

                case 5:
                    System.out.print("Enter name to search: ");
                    String search = sc.nextLine();
                    dao.searchItem(search);
                    break;

                case 6:
                    System.out.println("Exiting...");
                    System.exit(0);

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
