import java.sql.*;
import java.util.*;

public class PetSupplyDAO {

    // Insert item
    public void addItem(Item item) {
        String sql = "INSERT INTO items(name, category, price) VALUES(?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, item.getName());
            ps.setString(2, item.getCategory());
            ps.setDouble(3, item.getPrice());
            ps.executeUpdate();

            System.out.println("Item added successfully!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Display all items
    public void viewItems() {
        String sql = "SELECT * FROM items";

        try (Connection con = DBConnection.getConnection();
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(sql)) {

            System.out.println("\n--- Available Supplies ---");

            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                        rs.getString("name") + " | " +
                        rs.getString("category") + " | Rs." +
                        rs.getDouble("price"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Update item price
    public void updatePrice(int id, double price) {
        String sql = "UPDATE items SET price=? WHERE id=?";

        try (Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setDouble(1, price);
            ps.setInt(2, id);
            ps.executeUpdate();

            System.out.println("Price updated!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Delete item
    public void deleteItem(int id) {
        String sql = "DELETE FROM items WHERE id=?";

        try (Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

            System.out.println("Item deleted!");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Search by name
    public void searchItem(String name) {
        String sql = "SELECT * FROM items WHERE name LIKE ?";

        try (Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, "%" + name + "%");
            ResultSet rs = ps.executeQuery();

            System.out.println("\n--- Search Results ---");
            while (rs.next()) {
                System.out.println(rs.getInt("id") + " | " +
                        rs.getString("name") + " | " +
                        rs.getString("category") + " | Rs." +
                        rs.getDouble("price"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
